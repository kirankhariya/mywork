﻿using System;


namespace HandsOn9._3
{
    class Program 
    {
        static void Main(string[] args)
        {
            
            try
            {
                Console.WriteLine("Enter First Number: ");
                string a = Console.ReadLine();
                Console.WriteLine("Enter Second Number: ");
                string b = Console.ReadLine();
                if (a.Equals("") || b.Equals(""))
                {
                    throw new InputMismatchException();
                }
                Console.WriteLine(int.Parse(a) + int.Parse(b));
                Console.ReadLine();
            }
            catch (InputMismatchException e)
            {
                Console.WriteLine("Please provide valid input.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Type numbers in correct format!");
               
            }
            Console.ReadKey();
        }
    }
}
