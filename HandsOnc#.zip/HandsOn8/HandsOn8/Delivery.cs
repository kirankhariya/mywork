﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOn8
{
    class Delivery
    {
     internal   void DisplayDeliveryDetails(String bowler, String batsman) {
            String[] s1 = bowler.Split(' ');
            String[] s2 = batsman.Split(' ');
            int n1 = s1.Length;
            int n2 = s2.Length;
            Console.WriteLine("Bowler - "+s1[n1 - 1]);
            Console.WriteLine("Batsman - "+s2[n2 - 1]);
        }
      internal  void DisplayDeliveryDetails(long runs) {
           
            if (runs == 4)
            {
                Console.WriteLine("It is a Four");
            }
            else if (runs == 6)
            {
                Console.WriteLine("It is a Six ");
            }
            else {
                Console.WriteLine("Number of runs scored in the delivery : " + runs);
            }
        }

       
    }
}
