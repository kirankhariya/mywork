﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOn8
{
    class Program
    {
        static void Main(string[] args)
        {
            Delivery d = new Delivery();
            Console.WriteLine("Enter the bowler name : ");
            String s1 = Console.ReadLine();
            Console.WriteLine("Enter the batsman name : ");
            String s2 = Console.ReadLine();
           

            Console.WriteLine("Enter the number of runs : ");
            long n = Int64.Parse(Console.ReadLine());

            d.DisplayDeliveryDetails(s1, s2);
            d.DisplayDeliveryDetails(n);
            Console.ReadLine();


        }
    }
}
