﻿using System;


namespace HandsOn7
{
    class Program
    {
        static void Main(string[] args)
        {
            Skill s = new Skill();
            Player p = new Player();
            Console.WriteLine("Please enter name of the player :");
            p.Name1 = Console.ReadLine();
            Console.WriteLine("Please enter skill name:");
            p.Name = Console.ReadLine();
            Console.WriteLine("Enter Experience In Years:");
            p.ExperienceInYears1 = int.Parse(Console.ReadLine());
           // p.setSkills(s);
            Console.WriteLine(Utility.DisplayPlayerSkillDetail(p));
            Console.ReadLine();

        }
    }
}
