﻿using System;


namespace HandsOn7
{
  public static class Utility
    {
        public static string DisplayPlayerSkillDetail(Player p)
        {
            return "Hi BCCI. Here is the player skill details: " + p.Name1 + ", " + "" + p.Name + " " + "with" + p.ExperienceInYears1 + " years of experiance";
        }
    }
}
