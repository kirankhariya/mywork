﻿using System;

namespace HandsOn7
{
   public class Skill
    {
        public string name;
        public   int ExperienceInYears;

       
        public int ExperienceInYears1 { get => ExperienceInYears; set => ExperienceInYears = value; }
        public string Name { get => name; set => name = value; }
    }
}
