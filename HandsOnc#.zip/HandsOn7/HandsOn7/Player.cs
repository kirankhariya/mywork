﻿using System;

namespace HandsOn7
{
    public class Player : Skill
    {
        Skill s = new Skill();
        public string name;

        public string Name1 { get => name; set => name = value; }

        /* public void setSkills(Skill s) {
this.s = s;
}
*/
    }
}
