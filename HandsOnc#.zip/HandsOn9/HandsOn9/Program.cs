﻿using System;


namespace HandsOn9
{
    class Program
    {
        static void Main(string[] args)
        {


            Console.WriteLine("Enter LOB name: ");
            string LOB = Console.ReadLine();
            Console.WriteLine("Enter AccountCount: ");
            int AccountCount=0;
            try
            {
                 AccountCount = int.Parse(Console.ReadLine());

            }
            catch (FormatException f)
            {
                Console.WriteLine("Incorrect value provided for Account count. Please check.");
            }
            Console.WriteLine($"The LOB {LOB} has  {AccountCount}  accounts ");
            Console.ReadLine();
        }
    }
}
