﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOn9
{
    class Program3
    {
        static void Main(string[] args)
        {

            try
            {
                Console.WriteLine("Enter First Number: ");
                string a = Console.ReadLine();
                Console.WriteLine("Enter Second Number: ");
                string b = Console.ReadLine();
                if (a.Equals("") || b.Equals(""))
                {
                    throw new InputMismatchException();
                }
                Console.WriteLine(int.Parse(a) + int.Parse(b));
                Console.ReadLine();
            }
            catch (InputMismatchException e)
            {
                Console.WriteLine("Please provide valid input.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Type numbers in correct format!");

            }
            Console.ReadKey();
        }
    }
}
