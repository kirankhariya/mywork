﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOn6
{
    class Delivery
    {
        private long _over;
        private long _ball;
        private long _run;
        private string _batsman;
        private string _bowler;
        private string _nonStriker;

        public long Over { get => _over; set => _over = value; }
        public long Ball { get => _ball; set => _ball = value; }
        public long Run { get => _run; set => _run = value; }
        public string Batsman { get => _batsman; set => _batsman = value; }
        public string Bowler { get => _bowler; set => _bowler = value; }
        public string NonStriker { get => _nonStriker; set => _nonStriker = value; }

        public Delivery() {
        }
        public Delivery(long _over, long _ball, long _run, string _batsman, string _bowler, string _nonStriker) {
            this._over = _over;
            this._ball = _ball;
            this._run = _run;
            this._batsman = _batsman;
            this._bowler = _bowler;
            this._nonStriker = _nonStriker;
        }
    }
}
