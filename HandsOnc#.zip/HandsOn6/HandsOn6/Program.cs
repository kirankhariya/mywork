﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOn6
{
    class Program
    {
        static void Main(string[] args)
        {
            Delivery d = new Delivery();
            //  Delivery d1 = new Delivery(1,1,4,"Dhoni","Dale","Suresh");
            Console.WriteLine("Enter the no. of over");
            d.Over = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the no. of balls");
            d.Ball = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the no. of runs");
            d.Run = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the name of batsman");
            d.Batsman = Console.ReadLine();
            Console.WriteLine("Enter the name of bowler");
            d.Bowler = Console.ReadLine();
            Console.WriteLine("Enter the name of nonStriker");
            d.NonStriker = Console.ReadLine();
            Delivery d1 = new Delivery(d.Over,d.Ball,d.Run,d.Batsman,d.Bowler,d.NonStriker);
            Console.WriteLine("Over: "+d.Over + " " + "Ball: " + d.Ball + " "+ "Run: " + d.Run + " "+ "Batsman: " + d.Batsman + " "+ "Bowler: " + d.Bowler + " " + "NonStriker: " + d.NonStriker);
            Console.ReadLine();
        }
    }
}
