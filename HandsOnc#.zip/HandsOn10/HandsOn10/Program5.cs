﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOn10
{
    class Program5
    {
        static void Main(string[] args)
        {
            IDictionary<int, string> dict = new Dictionary<int, string>();
            dict.Add(1, "Alok");
            dict.Add(2, "Nadeem");
            dict.Add(3, "Udit");
            foreach (KeyValuePair<int, string> item in dict)
            {
                Console.WriteLine("Id: {0}, Name: {1}", item.Key, item.Value);
            }
            Console.ReadLine();
        }
        }
}
