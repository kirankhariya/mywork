﻿using System;

namespace HandsOn10
{
    class Program2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter team name : ");
            string s = Console.ReadLine();
            Console.WriteLine("Enter starting index: ");
            int x = Int32.Parse(Console.ReadLine());
            string s1 = s.Substring(x);
            int l = s1.Length;
            Console.Write(l + " ");
            Console.WriteLine(s1);
            Console.ReadLine();
        }
        }
}
