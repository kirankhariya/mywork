﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOn10
{
    class Program3
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter venue 1 : ");
            string s1 = Console.ReadLine();
            Console.WriteLine("Enter venue 2 : ");
            string s2 = Console.ReadLine();
            if (s1.Equals(s2, StringComparison.InvariantCultureIgnoreCase))
            {
                Console.WriteLine("Both the venues are same");
            }
            else
            {
                Console.WriteLine("Both the venues are different");
            }
            Console.ReadLine();
        }
    }
}
