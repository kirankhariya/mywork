﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOn10
{
    class Program
    {
        static void Main(string[] args)
        {
            /* Console.WriteLine("Enter Player name: ");
             string s = Console.ReadLine();
             Console.WriteLine("Enter starting index: ");
             int x = Int32.Parse(Console.ReadLine());
             Console.WriteLine(s.Substring(x));
             Console.ReadLine();
             */
           
        }
    }
}
