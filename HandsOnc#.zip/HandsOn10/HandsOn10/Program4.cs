﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOn10
{
    class Program4
    {
        static void Main(string[] args)
        {
            List<String> l = new List<String>();
            l.Add("Videocon");
            l.Add("Onida");
            l.Add("Samsung ");
            Console.WriteLine("Please enter the Television brand to add to the list : ");
            string s1 = Console.ReadLine();
            l.Add(s1);
            Console.WriteLine($"List of currently available {l.Count} Television brands ");
            foreach (string s in l)
            {
                Console.Write(s + " ");
            }
            Console.ReadLine();
        }
        }
}
