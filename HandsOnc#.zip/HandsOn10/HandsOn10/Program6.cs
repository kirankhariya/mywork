﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOn10
{
    class Program6
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of matches played by CSK: ");

            int n = Int32.Parse(Console.ReadLine());
            int[] a = new int[n];
            for (int i = 0; i < n; i++)
            {
                a[i] = int.Parse(Console.ReadLine());
            }
            Double s = 0;
            for (int i = 0; i < n; i++)
            {
                s += a[i];
            }
            Console.WriteLine(s);
          //  double d = s / a.Length;
            Console.WriteLine(s / a.Length);
            Console.ReadLine();
        }
        }
}
