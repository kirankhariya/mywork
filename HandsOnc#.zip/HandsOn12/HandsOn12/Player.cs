﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOn12
{
   public class Player
    {
        string playerName;
        long _runs;

        public string PlayerName { get => playerName; set => playerName = value; }
        public long Runs { get => _runs; set  => _runs = value; }

        public Player() { }
        public Player(string playerName, long _runs) {
            this.playerName = playerName;
            this._runs = _runs;
        }
    }
}
