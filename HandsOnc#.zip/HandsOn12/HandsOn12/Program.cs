﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOn12
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of players: ");
            int n = int.Parse(Console.ReadLine());

            List<Player> p = new List<Player>();  
            for(int i=0;i<n;i++)
            {
                Console.WriteLine("Enter player name: ");
                string playerName = Console.ReadLine();
                Console.WriteLine("Enter score: ");
                int score = int.Parse(Console.ReadLine());
                Player p1 = new Player(playerName, score);
                p.Add(p1);
            }

            var v = from a in p where a.Runs > 50 select a;
            foreach (Player p1 in v) {
                Console.WriteLine(p1.PlayerName);
                Console.WriteLine(p1.Runs);
            }
            Console.ReadLine();
        }
    }
}
