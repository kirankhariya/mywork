﻿using System;


namespace ConsoleApp3
{
    class TeamSelection
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number of teams that are qualified for the tournament");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter names of teams ");
            string[] s = new string[a];
            for (int i = 0; i < a; i++)
            {
                s[i] = Console.ReadLine();
            }
            Console.WriteLine("Enter the team name that is to be checked in the list of qualified teams:");
            string s1 = Console.ReadLine();
            int k = -1;
            if (a <= 0) {
                Console.WriteLine("Invalid Input");
            }
            else
            {
                for (int i = 0; i < a; i++)
                {
                    if ((string.Compare(s1, s[i])) == 1)
                    {
                        k = i;
                       
                    }
                }
            }
            if (k >= 0)
            {
                Console.WriteLine("Yes");
                Console.WriteLine(k);
               
            }
            else {
                Console.WriteLine("No");

            }
            Console.ReadLine();
        }
        }
        }
        
    

