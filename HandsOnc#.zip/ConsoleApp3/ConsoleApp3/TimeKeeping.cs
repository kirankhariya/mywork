﻿using System;


namespace ConsoleApp3
{
    class TimeKeeping
    {
        public void Main(string[] args) {
            Console.WriteLine("Enter the string: ");
            string s = Console.ReadLine();
            if (string.Compare(s, "Morning") == 1)
            {
                Console.WriteLine("Friends");
            }
            else if (string.Compare(s, "Afternoon") == 1)
            {
                Console.WriteLine("Girlfriend");
            }
            else if (string.Compare(s, "Evening") == 1)
            {
                Console.WriteLine("Practice");
            }
            else
            {
                Console.WriteLine("Biking");
            }
        }
    }
}
