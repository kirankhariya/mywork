﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4._1
{
    class NumberOfDays
    {
        public void Main(string[] args)
        {
            DateTime d1 = DateTime.Now;
            DateTime d2 = new DateTime(2020, 2, 26);

            //TimeSpan t = d1 - d2;
            //  double NrOfDays = t.TotalDays;
            Console.WriteLine((d1 - d2).TotalDays);
        }
    }
}
