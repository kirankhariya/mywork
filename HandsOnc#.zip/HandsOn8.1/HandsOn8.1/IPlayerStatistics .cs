﻿using System;


namespace HandsOn8._1
{
    interface IPlayerStatistics
    {
         void DisplayPlayerStatistics();
    }
}
