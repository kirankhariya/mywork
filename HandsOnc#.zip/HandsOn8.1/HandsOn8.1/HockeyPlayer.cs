﻿using System;


namespace HandsOn8._1
{
    class HockeyPlayer : Player,IPlayerStatistics
    {
        private string _position;
        private int _noOfGoals;
       
       public HockeyPlayer()
        {

        }
       public HockeyPlayer(string _position, int _noOfGoals) {
            this.Position = _position;
            this.NoOfGoals = _noOfGoals;
        }

        public string Position { get => _position; set => _position = value; }
        public int NoOfGoals { get => _noOfGoals; set => _noOfGoals = value; }

        public void DisplayPlayerStatistics() {
            Console.WriteLine($"Name :  {Name} Team Name : { TeamName}  No of Matches : {NoOfMatches} Position : {Position} No of Goals : {NoOfGoals}");
        }
    }
}
