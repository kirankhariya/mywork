﻿using System;


namespace HandsOn8._1
{
    class CricketPlayer : Player,IPlayerStatistics
    {
        protected int _totalRunsScored;
        protected int _noOfWicketsTaken;
        public CricketPlayer() {

        }

        public CricketPlayer(int _totalRunsScored, int _noOfWicketsTaken)
        {
            this.TotalRunsScored = _totalRunsScored;
            this.NoOfWicketsTaken = _noOfWicketsTaken;
        }

        public int TotalRunsScored { get => _totalRunsScored; set => _totalRunsScored = value; }
        public int NoOfWicketsTaken { get => _noOfWicketsTaken; set => _noOfWicketsTaken = value; }

        public void DisplayPlayerStatistics() {
            Console.WriteLine($"Name :  {Name} Team Name : { TeamName}  No of Matches : {NoOfMatches} Total Runs Scored : { TotalRunsScored} No of wickets Taken : {NoOfWicketsTaken}");
        }
    }
}
