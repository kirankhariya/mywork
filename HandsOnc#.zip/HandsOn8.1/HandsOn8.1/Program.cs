﻿using System;

namespace HandsOn8._1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(" Menu : ");
            Console.WriteLine("1.Cricket Player Details ");
            Console.WriteLine("2.Hockey Player Details ");
            int choice = int.Parse(Console.ReadLine());
            if (choice == 1)
            {
                CricketPlayer p = new CricketPlayer();
                Console.WriteLine("Enter player name : ");
                string playerName = Console.ReadLine();
                Console.WriteLine("Enter team name : ");
                string teamName = Console.ReadLine();
                Console.WriteLine("Enter number of matches played : ");
                int noOfMatches = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter total runs scored : ");
                int runs = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter total number of wickets taken  : ");
                int wickets = int.Parse(Console.ReadLine());
                p.Name = playerName;
                p.TeamName = teamName;
                p.NoOfMatches = noOfMatches;
                p.TotalRunsScored = runs;
                p.NoOfWicketsTaken = wickets;
                p.DisplayPlayerStatistics();
                Console.ReadLine();


            }
            else if (choice == 2)
            {
                HockeyPlayer h = new HockeyPlayer();
                Console.WriteLine("Enter player name : ");
                string playerName = Console.ReadLine();
                Console.WriteLine("Enter team name : ");
                string teamName = Console.ReadLine();
                Console.WriteLine("Enter number of matches played : ");
                int noOfMatches = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter the position  : ");
                string position = Console.ReadLine();
                Console.WriteLine("Enter total number of goals taken : ");
                int goals = int.Parse(Console.ReadLine());
                h.Name = playerName;
                h.TeamName = teamName;
                h.NoOfMatches = noOfMatches;
                h.Position = position;
                h.NoOfGoals = goals;
                h.DisplayPlayerStatistics();
                Console.ReadLine();

            }
            else {
                Console.WriteLine("Invalid choice ");
                Console.ReadLine();
            }
        }
    }
}
