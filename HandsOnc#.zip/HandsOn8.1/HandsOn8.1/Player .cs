﻿using System;


namespace HandsOn8._1
{
  public abstract class Player
    {
        protected string name;
        protected string teamName;
        protected int noOfMatches;

        public string Name { get => name; set => name = value; }
        public string TeamName { get => teamName; set => teamName = value; }
        public int NoOfMatches { get => noOfMatches; set => noOfMatches = value; }


        public Player() {
        }
        Player(string _name, string _teamName, int _noOfMatches) {
            this.Name = _name;
            this.TeamName = _teamName;
            this.NoOfMatches = _noOfMatches;
        }
    }
}
