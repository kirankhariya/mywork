﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOn9._2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter LOB name: ");
            string LOB = Console.ReadLine();
            Console.WriteLine("Enter AccountCount: ");
            string AccountCount = Console.ReadLine();
            try
            {
               
                Console.WriteLine(Utility.GetLOBAcctCount(LOB, AccountCount));
                
            }
            catch (Exception e)
            {
                Console.WriteLine("The exception is caught in Main method.");
               
            }
            Console.ReadKey();
        }
    }
}
