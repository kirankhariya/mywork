﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HandsOn9._2
{
    public static class Utility
    {
       
        public static string GetLOBAcctCount(string LOB, string AccountCount)
        {
            int ac = 0;
            try
            {
                ac = int.Parse(AccountCount);
                return "The LOB " + LOB + " has " + AccountCount + " accounts";
            }
            catch (FormatException f)
            {
                return "Incorrect value provided for Account count. Please check.";
            }
          //  return "The LOB " + LOB + " has " + AccountCount + " accounts";
        }
   
    }
}
