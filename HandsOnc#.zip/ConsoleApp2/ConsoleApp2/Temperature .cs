﻿using System;


namespace ConsoleApp2
{
    class Temperature
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter temperature in fahrenheit:");
            double a = Convert.ToInt64(Console.ReadLine());
            double b = (a - 32) / 1.8;
          
            Console.WriteLine(b);
            Console.ReadLine();
        }
    }
}
