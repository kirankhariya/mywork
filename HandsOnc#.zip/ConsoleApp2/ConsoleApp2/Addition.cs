﻿using System;


namespace ConsoleApp2
{
    class Addition
    {
        static int add(int a, int b)
        {
            return a + b;

        }
        static void Main(string[] args)
        {
            Console.WriteLine("Enter first number");
            int a = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter second number");
            int b = int.Parse(Console.ReadLine());
            int s = add(a, b);
            Console.WriteLine(s);
            Console.ReadLine();
        }
    }
}
