﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace HandsOn11
{
    class Program2
    {
        static void Main(string[] args)
        {
            XmlDocument d = new XmlDocument();
            d.Load("xmlFile.txt");
           
            foreach (XmlNode node in d.DocumentElement.SelectNodes("/CTSLOB/LOB"))
            {
                string text = node.InnerText; //or loop through its children as well
                Console.WriteLine(text);
            }
            Console.ReadKey();
        }
        }
}
