﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    class VoteCount
    {
        public void Main(string[] args) {
            int[] votes = { 2000, 3000, 2000, 1000 };

            for (int i = 0; i < votes.Length; i++)
            {
                Console.Write($"{i + 1} - {votes[i]},  ");
            }

            Console.Write("\n\nPlease provide the constituency number for which the vote count should be modified: ");
            int index = int.Parse(Console.ReadLine());

            Console.Write("\nPlease provide the new vote count: ");
            int newvotes = int.Parse(Console.ReadLine());

            votes[index - 1] = newvotes;

            Console.WriteLine("Current constituency vote count details in ‘Constituency number – vote count’ format: ");

            for (int i = 0; i < votes.Length; i++)
            {
                Console.Write($"{i + 1} - {votes[i]}  ");
            }

            Console.Write("\nPress any key to Exit..");
            Console.ReadKey();
        }
    }
}
