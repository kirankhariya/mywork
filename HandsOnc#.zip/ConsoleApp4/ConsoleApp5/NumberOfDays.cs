﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    class NumberOfDays
    {
        static void Main(string[] args)
        {
            DateTime d1 = DateTime.Now;
            DateTime d2 = new DateTime(2020, 1, 14);

            Console.WriteLine((d1 - d2).TotalDays);
            Console.ReadLine();

        }
    }
}
