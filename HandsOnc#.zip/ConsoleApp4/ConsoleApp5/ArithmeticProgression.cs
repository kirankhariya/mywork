﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    class ArithmeticProgression
    {
        public void Main(string[] args) {
            int n  = int.Parse(Console.ReadLine());
            int d = 2;
            for (int i = 1; i <= 10; i+=d)
            {
                Console.WriteLine(i);
               
            }
            Console.ReadLine();
        }
    }
}
