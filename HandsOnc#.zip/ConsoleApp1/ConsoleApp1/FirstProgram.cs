﻿using System;


namespace ConsoleApp1
{
    class FirstProgram
    {
        static void Main(string[] args) {
            Console.WriteLine("“Hurray! My First Program In C#!!!”");
            Console.ReadLine();
        }
    }
}
